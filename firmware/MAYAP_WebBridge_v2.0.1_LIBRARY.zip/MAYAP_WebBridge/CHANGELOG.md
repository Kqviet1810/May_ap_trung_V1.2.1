# Changelog

## 2.0.1
- Tang RX queue tu 3 len 6 goi.
- Them log CONFIG/COMMAND RX, subscribe va PUBACK QoS1.
- Khong doi API, topic hay payload.

# Changelog

## 2.0.0

- Tách hoàn toàn transport khỏi schema máy.
- Captive portal Wi-Fi tích hợp.
- ESP-MQTT TLS, reconnect, LWT/presence.
- RX queue tĩnh và xử lý callback ngoài MQTT task.
- Raw channels cho config, command, ACK, snapshot và log.
- Session điều chỉnh nhịp snapshot/power-save.
- Ví dụ standalone không kích GPIO.

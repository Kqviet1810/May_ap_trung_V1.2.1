#include <Arduino.h>
#include <MAYAP_WebBridge.h>

#include "DemoCertificates.h"
#include "StandaloneDemo.h"

mayap::WebBridge WebBridge;
StandaloneDemo Demo;

void setup() {
  Serial.begin(115200);
  Serial.println();
  Serial.println(F("=== MAYAP WebBridge v2.0.0 STANDALONE ==="));
  Serial.println(F("Khong khai bao GPIO chap hanh, khong kich relay."));

  mayap::BridgeOptions options{};
  options.apPrefix = "MAYAP";
  options.brokerUri = "mqtts://broker.emqx.io:8883"; // Chi de test.
  options.mqttUsername = "";
  options.mqttPassword = "";
  options.rootCaPem = MAYAP_TEST_ROOT_CA;
  options.topicRoot = "mayap/v1";
  options.firmwareVersion = "webbridge-2.0.0-standalone";
  options.mqttTaskPriority = 1U;
  options.mqttTaskStackBytes = 7168U;
  options.allowInsecureTls = false;
  options.enableSerialLog = true;

  Demo.begin(WebBridge);
  const bool ok = WebBridge.begin(options, Demo.callbacks());
  Serial.printf("[Bridge] %s | Device ID: %s\n",
                ok ? "READY" : "FAILED", WebBridge.deviceId());
  Serial.println(F("Lan dau: ket noi MAYAP-XXXX, mo 192.168.4.1 va nhap Wi-Fi."));
}

void loop() {
  WebBridge.loop();
  Demo.loop();
  yield();
}

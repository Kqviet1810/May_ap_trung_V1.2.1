#pragma once

#include <Arduino.h>
#include <MAYAP_WebBridge.h>
#include <esp_system.h>
#include <time.h>
#include <string.h>

// Mo phong giao tiep, KHONG khai bao GPIO va KHONG kich relay.
class StandaloneDemo {
 public:
  bool begin(mayap::WebBridge &bridge) {
    bridge_ = &bridge;
    bootId_ = esp_random();
    snapshotDue_ = true;
    return true;
  }

  mayap::BridgeCallbacks callbacks() {
    mayap::BridgeCallbacks cb{};
    cb.context = this;
    cb.onMessage = &StandaloneDemo::onMessageThunk;
    cb.onConnectionChanged = &StandaloneDemo::onConnectionThunk;
    cb.onSessionChanged = &StandaloneDemo::onSessionThunk;
    return cb;
  }

  void loop() {
    if (!bridge_) return;
    if (bridge_->takeSyncRequest()) snapshotDue_ = true;
    if (ackLength_ && bridge_->mqttOnline() &&
        bridge_->publish(mayap::OutboundChannel::Ack, ack_, ackLength_)) {
      ackLength_ = 0U;
      return;
    }
    const uint32_t now = millis();
    const uint32_t period = bridge_->sessionActive() ? 2000U : 30000U;
    if ((snapshotDue_ || nextSnapshotAt_ == 0U || reached(now, nextSnapshotAt_)) &&
        bridge_->mqttOnline()) {
      char payload[768];
      const float wave = sinf(static_cast<float>(now % 60000UL) * 6.2831853f / 60000.0f);
      const int n = snprintf(payload, sizeof(payload),
          "{\"v\":1,\"deviceId\":\"%s\",\"bootId\":%lu,\"sequence\":%lu,"
          "\"epoch\":%lu,\"runtime\":{\"temperature\":%.2f,\"humidity\":%.2f,"
          "\"sensorOnline\":true,\"batchRunning\":%s,\"heaterOn\":%s,"
          "\"turnState\":\"%s\",\"machineState\":\"%s\"},"
          "\"status\":{\"systemHealthy\":true,\"uptimeSec\":%lu}}",
          bridge_->deviceId(), static_cast<unsigned long>(bootId_),
          static_cast<unsigned long>(++snapshotSequence_), epochNow(),
          37.5f + wave * 0.15f, 58.0f + wave,
          batchRunning_ ? "true" : "false",
          batchRunning_ && wave < -0.1f ? "true" : "false",
          turnState_, batchRunning_ ? "DANG AP DEMO" : "SAN SANG DEMO",
          static_cast<unsigned long>(now / 1000UL));
      if (n > 0 && static_cast<size_t>(n) < sizeof(payload) &&
          bridge_->publish(mayap::OutboundChannel::Snapshot, payload,
                           static_cast<size_t>(n))) {
        snapshotDue_ = false;
        nextSnapshotAt_ = now + period;
      }
    }
  }

 private:
  mayap::WebBridge *bridge_ = nullptr;
  uint32_t bootId_ = 0U;
  uint32_t snapshotSequence_ = 0U;
  uint32_t currentRevision_ = 0U;
  uint32_t nextSnapshotAt_ = 0U;
  bool snapshotDue_ = false;
  bool batchRunning_ = false;
  char turnState_[12] = "STOP";
  char ack_[512]{};
  uint16_t ackLength_ = 0U;

  static void onMessageThunk(void *context, mayap::InboundChannel channel,
                             const char *payload, size_t length, bool retained) {
    if (context) static_cast<StandaloneDemo *>(context)->onMessage(
        channel, payload, length, retained);
  }
  static void onConnectionThunk(void *context, bool online) {
    if (online && context) static_cast<StandaloneDemo *>(context)->snapshotDue_ = true;
  }
  static void onSessionThunk(void *context, bool) {
    if (context) static_cast<StandaloneDemo *>(context)->snapshotDue_ = true;
  }

  void onMessage(mayap::InboundChannel channel, const char *payload,
                 size_t length, bool retained) {
    if (!payload || !length || ackLength_) return;
    char requestId[40]{};
    (void)readString(payload, "requestId", requestId, sizeof(requestId));
    if (channel == mayap::InboundChannel::ConfigSet) {
      uint32_t revision = 0U;
      const bool ok = readU32(payload, "revision", revision) &&
                      revision > currentRevision_;
      if (ok) currentRevision_ = revision;
      makeAck(requestId, 0U, "config", ok ? "applied" : "duplicate",
              ok ? "DEMO DA NHAN CAU HINH" : "REVISION CU/TRUNG");
      snapshotDue_ = true;
      return;
    }
    if (retained) {
      makeAck(requestId, 0U, "command", "rejected", "RETAINED COMMAND BI CHAN");
      return;
    }
    uint32_t sequence = 0U;
    uint32_t commandBootId = 0U;
    char action[32]{};
    const bool valid = readU32(payload, "sequence", sequence) &&
                       readU32(payload, "bootId", commandBootId) &&
                       commandBootId == bootId_ &&
                       readString(payload, "action", action, sizeof(action));
    if (!valid) {
      makeAck(requestId, sequence, "command", "invalid", "PAYLOAD/BOOT ID SAI");
      return;
    }
    if (strcmp(action, "batch_start") == 0) batchRunning_ = true;
    else if (strcmp(action, "batch_stop") == 0) batchRunning_ = false;
    else if (strcmp(action, "turn_left") == 0) snprintf(turnState_, sizeof(turnState_), "LEFT");
    else if (strcmp(action, "turn_right") == 0) snprintf(turnState_, sizeof(turnState_), "RIGHT");
    else if (strcmp(action, "turn_stop") == 0) snprintf(turnState_, sizeof(turnState_), "STOP");
    else if (strcmp(action, "alarm_ack") != 0 &&
             strcmp(action, "autotune_start") != 0) {
      makeAck(requestId, sequence, "command", "unsupported", "LENH DEMO CHUA CO");
      return;
    }
    makeAck(requestId, sequence, "command", "accepted", "DEMO DA NHAN LENH");
    snapshotDue_ = true;
  }

  void makeAck(const char *requestId, uint32_t sequence, const char *kind,
               const char *result, const char *message) {
    const int n = snprintf(ack_, sizeof(ack_),
        "{\"v\":1,\"deviceId\":\"%s\",\"bootId\":%lu,"
        "\"requestId\":\"%s\",\"sequence\":%lu,\"kind\":\"%s\","
        "\"result\":\"%s\",\"message\":\"%s\",\"revision\":%lu}",
        bridge_ ? bridge_->deviceId() : "", static_cast<unsigned long>(bootId_),
        requestId ? requestId : "", static_cast<unsigned long>(sequence),
        kind, result, message, static_cast<unsigned long>(currentRevision_));
    ackLength_ = (n > 0 && static_cast<size_t>(n) < sizeof(ack_))
        ? static_cast<uint16_t>(n) : 0U;
  }

  static bool reached(uint32_t now, uint32_t deadline) {
    return static_cast<int32_t>(now - deadline) >= 0;
  }
  static unsigned long epochNow() {
    const time_t now = time(nullptr);
    return now > 1700000000 ? static_cast<unsigned long>(now) : 0UL;
  }
  static const char *findValue(const char *json, const char *key) {
    char pattern[48];
    snprintf(pattern, sizeof(pattern), "\"%s\"", key);
    const char *p = strstr(json, pattern);
    if (!p) return nullptr;
    p += strlen(pattern);
    while (*p == ' ' || *p == '\t' || *p == '\r' || *p == '\n') ++p;
    if (*p++ != ':') return nullptr;
    while (*p == ' ' || *p == '\t' || *p == '\r' || *p == '\n') ++p;
    return p;
  }
  static bool readU32(const char *json, const char *key, uint32_t &out) {
    const char *p = findValue(json, key);
    if (!p || *p < '0' || *p > '9') return false;
    uint64_t value = 0U;
    while (*p >= '0' && *p <= '9') {
      value = value * 10U + static_cast<uint8_t>(*p++ - '0');
      if (value > UINT32_MAX) return false;
    }
    out = static_cast<uint32_t>(value);
    return true;
  }
  static bool readString(const char *json, const char *key,
                         char *out, size_t capacity) {
    if (!out || capacity == 0U) return false;
    const char *p = findValue(json, key);
    if (!p || *p++ != '"') return false;
    size_t used = 0U;
    while (*p && *p != '"') {
      if (used + 1U >= capacity) return false;
      out[used++] = *p++;
    }
    if (*p != '"') return false;
    out[used] = '\0';
    return used != 0U;
  }
};

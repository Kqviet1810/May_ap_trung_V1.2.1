#pragma once

#include <Arduino.h>
#include <WiFi.h>
#include <WebServer.h>
#include <DNSServer.h>
#include <Preferences.h>
#include <mqtt_client.h>
#include <freertos/FreeRTOS.h>
#include <freertos/queue.h>

#include "MAYAP_WebBridgeTypes.h"

#define MAYAP_WEBBRIDGE_VERSION "2.0.1"

namespace mayap {

class WebBridge {
 public:
  WebBridge();
  ~WebBridge();

  bool begin(const BridgeOptions &options, const BridgeCallbacks &callbacks);
  void loop();
  void end();

  bool publish(OutboundChannel channel,
               const char *payload,
               size_t payloadLength,
               int qos = -1,
               int retain = -1,
               bool store = true);

  bool mqttOnline() const { return mqttConnected_; }
  bool wifiOnline() const { return WiFi.status() == WL_CONNECTED; }
  bool portalOpen() const { return portalActive_; }
  bool sessionActive() const;
  bool takeSyncRequest();
  ConnectionState state() const { return state_; }

  const char *deviceId() const { return deviceId_; }
  const char *wifiSsid() const { return wifiSsid_; }
  uint32_t droppedRxPackets() const { return rxDropped_; }
  uint32_t rejectedOversizePackets() const { return rxOversize_; }

  void clearNetworkAndOpenPortal();

 private:
  static constexpr size_t SSID_MAX = 32;
  static constexpr size_t WIFI_PASS_MAX = 63;
  static constexpr size_t URI_MAX = 180;
  static constexpr size_t USER_MAX = 64;
  static constexpr size_t MQTT_PASS_MAX = 96;
  static constexpr size_t TOPIC_MAX = 128;
  static constexpr size_t RX_PAYLOAD_MAX = 2304;
  static constexpr uint8_t RX_QUEUE_LENGTH = 6;

  enum class RxKind : uint8_t { Unknown = 0, Config, Command, Session };

  struct RxPacket {
    RxKind kind = RxKind::Unknown;
    bool retained = false;
    uint16_t length = 0;
    char payload[RX_PAYLOAD_MAX + 1] = {};
  };

  BridgeOptions options_{};
  BridgeCallbacks callbacks_{};
  bool begun_ = false;

  Preferences prefs_;
  WebServer server_;
  DNSServer dns_;
  bool routesConfigured_ = false;
  bool portalActive_ = false;
  bool webServerStarted_ = false;
  bool wifiConfigSaved_ = false;
  bool wifiAttemptActive_ = false;
  bool wifiWasConnected_ = false;
  bool pendingSaveAfterConnect_ = false;
  uint32_t wifiAttemptStartedAt_ = 0;
  uint32_t wifiReconnectAt_ = 0;

  char deviceId_[24] = {};
  char apSsid_[40] = {};
  char wifiSsid_[SSID_MAX + 1] = {};
  char wifiPassword_[WIFI_PASS_MAX + 1] = {};
  char pendingSsid_[SSID_MAX + 1] = {};
  char pendingWifiPassword_[WIFI_PASS_MAX + 1] = {};
  char brokerUri_[URI_MAX + 1] = {};
  char mqttUsername_[USER_MAX + 1] = {};
  char mqttPassword_[MQTT_PASS_MAX + 1] = {};

  esp_mqtt_client_handle_t mqttClient_ = nullptr;
  volatile bool mqttConnected_ = false;
  volatile int8_t mqttConnectionEvent_ = 0;
  bool mqttStarted_ = false;
  uint32_t mqttStartAt_ = 0;
  uint32_t sessionUntil_ = 0;
  bool sessionWasActive_ = false;
  bool realtimeWifi_ = false;
  bool syncRequested_ = false;
  bool presencePending_ = false;
  ConnectionState state_ = ConnectionState::Offline;

  char topicBase_[TOPIC_MAX] = {};
  char topicConfigSet_[TOPIC_MAX] = {};
  char topicConfigReported_[TOPIC_MAX] = {};
  char topicCommand_[TOPIC_MAX] = {};
  char topicAck_[TOPIC_MAX] = {};
  char topicSnapshot_[TOPIC_MAX] = {};
  char topicLog_[TOPIC_MAX] = {};
  char topicPresence_[TOPIC_MAX] = {};
  char topicSession_[TOPIC_MAX] = {};
  char lastWill_[160] = {};

  StaticQueue_t rxQueueStruct_{};
  uint8_t rxQueueStorage_[RX_QUEUE_LENGTH * sizeof(RxPacket)] = {};
  QueueHandle_t rxQueue_ = nullptr;
  RxPacket rxAssembly_{};
  RxPacket rxProcessing_{};
  uint16_t rxAssemblyExpected_ = 0;
  uint16_t rxAssemblyOffset_ = 0;
  volatile uint32_t rxDropped_ = 0;
  volatile uint32_t rxOversize_ = 0;

  uint32_t resetPressedAt_ = 0;
  bool resetHandled_ = false;
  bool restartPending_ = false;
  uint32_t restartAt_ = 0;

  static void mqttEventThunk(void *handlerArgs,
                             esp_event_base_t eventBase,
                             int32_t eventId,
                             void *eventData);
  void onMqttEvent(int32_t eventId, esp_mqtt_event_handle_t event);

  void log(const char *message) const;
  void logf(const char *format, ...) const __attribute__((format(printf, 2, 3)));
  void makeIdentity();
  void buildTopics();

  bool loadNetworkSettings();
  bool savePendingNetworkSettings();
  void clearNetworkSettings();
  void beginWifiAttempt(const char *ssid,
                        const char *password,
                        bool saveAfterConnect);
  void serviceNetwork();
  void onWifiConnected();
  void onWifiDisconnected();

  void configurePortalRoutes();
  void startPortal();
  void stopPortal();
  void servicePortal();
  void beginScan();
  void sendJson(int code, const char *json);
  void sendMessage(int code, const char *message);
  void handlePortalIndex();
  void handlePortalStatus();
  void handlePortalNetworks();
  void handlePortalSave();
  void handlePortalReset();
  void handlePortalRestart();
  void handlePortalRedirect();

  bool startMqtt();
  void stopMqtt();
  void serviceMqtt();
  bool timeReadyForTls();
  bool isSecureBroker() const;
  void setRealtimeWifi(bool active);
  void processOneRx();
  void handleSessionPayload(const char *payload, size_t length, bool retained);
  RxKind classifyTopic(const char *topic, size_t length) const;
  bool enqueuePublish(const char *topic,
                      const char *payload,
                      size_t length,
                      int qos,
                      bool retain,
                      bool store);
  const char *topicFor(OutboundChannel channel) const;
  void publishPresence(bool online);

  void serviceResetButton();
  void serviceScheduledRestart();

  static bool deadlineReached(uint32_t deadline);
  static bool copyText(char *destination, size_t capacity, const String &source);
  static bool copyText(char *destination, size_t capacity, const char *source);
  static bool validBrokerUri(const char *value);
  static void jsonEscapeTo(const char *input, char *output, size_t capacity);
};

}  // namespace mayap

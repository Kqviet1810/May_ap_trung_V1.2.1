#pragma once

#include <Arduino.h>

namespace mayap {

enum class ConnectionState : uint8_t {
  Offline = 0,
  WifiConnecting,
  TimeSync,
  MqttConnecting,
  Online,
  Portal
};

// Thu vien chi biet kenh van chuyen, khong biet MachineConfig/HMI/PID.
// Them nut moi tren web van gui vao Command; khong can sua thu vien.
enum class InboundChannel : uint8_t {
  ConfigSet = 0,
  Command = 1
};

enum class OutboundChannel : uint8_t {
  ConfigReported = 0,
  Ack,
  Snapshot,
  Log
};

struct BridgeCallbacks {
  void *context = nullptr;

  // Duoc goi tu WebBridge::loop(), KHONG goi trong MQTT task.
  // Callback chi nen parse/copy vao mailbox va tra ve nhanh.
  void (*onMessage)(void *context,
                    InboundChannel channel,
                    const char *payload,
                    size_t payloadLength,
                    bool retained) = nullptr;

  void (*onConnectionChanged)(void *context, bool online) = nullptr;
  void (*onSessionChanged)(void *context, bool active) = nullptr;
};

struct BridgeOptions {
  const char *apPrefix = "MAYAP";
  const char *brokerUri = "";
  const char *mqttUsername = "";
  const char *mqttPassword = "";
  const char *rootCaPem = nullptr;
  const char *topicRoot = "mayap/v1";
  const char *firmwareVersion = "unknown";

  uint32_t wifiConnectTimeoutMs = 15000;
  uint32_t wifiReconnectMs = 10000;
  uint32_t mqttReconnectMs = 5000;
  uint32_t networkTimeoutMs = 8000;
  uint32_t keepAliveSeconds = 60;
  uint32_t sessionDefaultMs = 15000;
  uint32_t sessionMaxMs = 30000;
  uint32_t maxOutboxBytes = 12288;

  uint16_t mqttTaskStackBytes = 7168;
  uint8_t mqttTaskPriority = 1;

  uint8_t resetButtonPin = 0;
  bool resetButtonActiveLow = true;
  uint32_t resetButtonHoldMs = 3000;

  bool allowInsecureTls = false;
  bool enableSerialLog = false;
};

}  // namespace mayap

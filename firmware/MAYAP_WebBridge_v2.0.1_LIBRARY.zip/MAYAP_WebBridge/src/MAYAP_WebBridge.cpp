#include "MAYAP_WebBridge.h"

#include <esp_wifi.h>
#include <esp_system.h>
#include <esp_idf_version.h>
#include <time.h>
#include <stdarg.h>
#include <string.h>

namespace mayap {
namespace {

static const IPAddress kPortalIp(192, 168, 4, 1);
static constexpr uint16_t kDnsPort = 53;
static constexpr uint32_t kMinValidEpoch = 1700000000UL;
static constexpr size_t kMaxScanResults = 20;

static const char kPortalHtml[] PROGMEM = R"HTML(
<!doctype html><html lang="vi"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="theme-color" content="#075f54"><title>Kết nối Wi‑Fi MAYAP</title>
<style>
:root{--p:#075f54;--a:#13a493;--bg:#edf6f4;--ink:#123c36;--mut:#6d8581;--line:#d4e2df;--err:#a53f3f}
*{box-sizing:border-box}html,body{margin:0;max-width:100%;overflow-x:hidden}body{background:var(--bg);font-family:system-ui,-apple-system,Segoe UI,sans-serif;color:var(--ink)}
main{width:min(100%,520px);margin:auto;padding:14px 12px 90px}.hero{padding:21px;border-radius:24px;color:#fff;background:linear-gradient(135deg,#064c44,var(--p));box-shadow:0 15px 35px #075f5425}.hero h1{font-size:23px;margin:0 0 6px}.hero p{font-size:13px;margin:0;color:#d5efea}.id{display:inline-block;margin-top:14px;padding:8px 11px;border:1px solid #ffffff35;border-radius:99px;font-size:12px}
.card{margin-top:12px;padding:18px;border:1px solid var(--line);border-radius:22px;background:#fff;box-shadow:0 8px 25px #123c360d}.card h2{font-size:18px;margin:0 0 5px}.lead{font-size:12px;color:var(--mut);margin:0 0 15px}.field{margin-top:13px}label{display:block;font-size:12px;font-weight:750;margin:0 0 6px}input,select{width:100%;min-width:0;height:49px;border:1px solid #bfd1cd;border-radius:14px;background:#fff;padding:0 12px;font-size:15px;color:var(--ink);outline:none}input:focus,select:focus{border-color:var(--a);box-shadow:0 0 0 3px #13a49317}.row{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:8px}.btn{height:49px;border:0;border-radius:14px;padding:0 15px;font-weight:750;cursor:pointer}.secondary{background:#e9f5f3;color:var(--p)}.primary{width:100%;margin-top:16px;background:var(--p);color:#fff}.status{margin-top:12px;min-height:42px;padding:11px 12px;border-radius:13px;background:#eff7f5;color:#4d6d67;font-size:12px;line-height:1.45}.status.error{background:#fff0f0;color:var(--err)}.tools{display:grid;grid-template-columns:1fr 1fr;gap:8px}.tools button{height:44px;border-radius:13px;border:1px solid var(--line);background:#fff;color:#526e69}.danger{color:var(--err)!important;border-color:#edcccc!important}@media(max-width:360px){.tools{grid-template-columns:1fr}}
</style></head><body><main>
<section class="hero"><h1>Kết nối máy ấp trứng</h1><p>Chọn Wi‑Fi 2.4 GHz. Các thông số Cloud đã được cài sẵn trong máy.</p><span class="id" id="device">Đang đọc ID…</span></section>
<section class="card"><h2>Đổi Wi‑Fi</h2><p class="lead">Chọn mạng tìm thấy hoặc nhập tên mạng thủ công.</p>
<div class="row"><select id="ssid"><option value="">Đang tìm Wi‑Fi…</option></select><button class="btn secondary" id="scan">Tìm lại</button></div>
<div class="field"><label for="manual">Tên Wi‑Fi nhập thủ công</label><input id="manual" maxlength="32" placeholder="Chỉ nhập khi không thấy trong danh sách"></div>
<div class="field"><label for="pass">Mật khẩu Wi‑Fi</label><input id="pass" type="password" maxlength="63" placeholder="Để trống nếu mạng mở"></div>
<button class="btn primary" id="save">Kết nối Wi‑Fi</button><div class="status" id="status">Sẵn sàng</div></section>
<section class="card"><h2>Bảo trì</h2><p class="lead">Giữ nút BOOT 3 giây cũng có thể xóa riêng Wi‑Fi.</p><div class="tools"><button id="restart">Khởi động lại</button><button class="danger" id="reset">Xóa Wi‑Fi đã lưu</button></div></section>
</main><script>
(()=>{'use strict';const $=id=>document.getElementById(id);const ui={device:$('device'),ssid:$('ssid'),manual:$('manual'),pass:$('pass'),scan:$('scan'),save:$('save'),status:$('status'),restart:$('restart'),reset:$('reset')};let polling=0;
async function api(url,opt={}){const r=await fetch(url,{cache:'no-store',...opt});const d=await r.json().catch(()=>({message:'Phản hồi không hợp lệ'}));if(!r.ok)throw Error(d.message||'Lỗi '+r.status);return d}
function state(text,error=false){ui.status.textContent=text;ui.status.className='status'+(error?' error':'')}
async function status(){try{const d=await api('/api/status');ui.device.textContent=(d.deviceId||'ESP32')+(d.mqtt?' · ONLINE':'');state(d.message||d.state);if(d.connected&&d.saved){state('Wi‑Fi đã kết nối. Có thể mở website và thêm ID thiết bị.');clearInterval(polling)}}catch(e){state(e.message,true)}}
async function scan(){ui.scan.disabled=true;state('Đang tìm Wi‑Fi…');try{let d=await api('/api/networks?rescan=1');for(let i=0;i<15&&d.scanning;i++){await new Promise(r=>setTimeout(r,600));d=await api('/api/networks')}ui.ssid.innerHTML='<option value="">Chọn Wi‑Fi</option>';for(const n of d.networks||[]){const o=document.createElement('option');o.value=n.ssid;o.textContent=n.ssid+' · '+n.rssi+' dBm';ui.ssid.appendChild(o)}state((d.networks||[]).length?'Đã tìm thấy '+d.networks.length+' mạng.':'Không thấy mạng; hãy nhập thủ công.')}catch(e){state(e.message,true)}finally{ui.scan.disabled=false}}
ui.save.onclick=async()=>{const ssid=(ui.manual.value.trim()||ui.ssid.value);if(!ssid)return state('Hãy chọn hoặc nhập tên Wi‑Fi.',true);if(ui.pass.value.length&&ui.pass.value.length<8)return state('Mật khẩu phải để trống hoặc có ít nhất 8 ký tự.',true);const body=new URLSearchParams({ssid,password:ui.pass.value});ui.save.disabled=true;try{const d=await api('/api/save',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body});state(d.message);clearInterval(polling);polling=setInterval(status,700)}catch(e){state(e.message,true);ui.save.disabled=false}};
ui.scan.onclick=scan;ui.restart.onclick=async()=>{if(confirm('Khởi động lại ESP32?')){await api('/api/restart',{method:'POST'}).catch(e=>state(e.message,true));state('ESP32 đang khởi động lại…')}};ui.reset.onclick=async()=>{if(confirm('Xóa Wi‑Fi đã lưu?')){await api('/api/reset',{method:'POST'}).catch(e=>state(e.message,true));state('Đã xóa Wi‑Fi. Chế độ cài đặt vẫn đang mở.')}};status();scan()})();
</script></body></html>
)HTML";

bool startsWith(const char *value, const char *prefix) {
  return value && prefix && strncmp(value, prefix, strlen(prefix)) == 0;
}

bool findJsonValue(const char *json, const char *key, const char *&value) {
  if (!json || !key) return false;
  char pattern[48];
  const int written = snprintf(pattern, sizeof(pattern), "\"%s\"", key);
  if (written <= 0 || static_cast<size_t>(written) >= sizeof(pattern)) return false;
  const char *position = strstr(json, pattern);
  if (!position) return false;
  position += written;
  while (*position == ' ' || *position == '\t' || *position == '\r' || *position == '\n') ++position;
  if (*position++ != ':') return false;
  while (*position == ' ' || *position == '\t' || *position == '\r' || *position == '\n') ++position;
  value = position;
  return true;
}

bool readJsonBool(const char *json, const char *key, bool &value) {
  const char *position = nullptr;
  if (!findJsonValue(json, key, position)) return false;
  if (strncmp(position, "true", 4) == 0) { value = true; return true; }
  if (strncmp(position, "false", 5) == 0) { value = false; return true; }
  return false;
}

bool readJsonU32(const char *json, const char *key, uint32_t &value) {
  const char *position = nullptr;
  if (!findJsonValue(json, key, position) || *position < '0' || *position > '9') return false;
  uint64_t parsed = 0;
  while (*position >= '0' && *position <= '9') {
    parsed = parsed * 10ULL + static_cast<uint8_t>(*position - '0');
    if (parsed > 0xFFFFFFFFULL) return false;
    ++position;
  }
  value = static_cast<uint32_t>(parsed);
  return true;
}

}  // namespace

WebBridge::WebBridge() : server_(80) {}
WebBridge::~WebBridge() { end(); }

bool WebBridge::begin(const BridgeOptions &options, const BridgeCallbacks &callbacks) {
  if (begun_) return true;
  options_ = options;
  callbacks_ = callbacks;
  if (options_.brokerUri && options_.brokerUri[0] &&
      !validBrokerUri(options_.brokerUri)) {
    log("[Bridge] Broker URI khong hop le; chi chay Wi-Fi/portal");
  }

  makeIdentity();
  buildTopics();
  copyText(brokerUri_, sizeof(brokerUri_), options_.brokerUri);
  copyText(mqttUsername_, sizeof(mqttUsername_), options_.mqttUsername);
  copyText(mqttPassword_, sizeof(mqttPassword_), options_.mqttPassword);

  rxQueue_ = xQueueCreateStatic(RX_QUEUE_LENGTH, sizeof(RxPacket),
                                rxQueueStorage_, &rxQueueStruct_);
  if (!rxQueue_) return false;

  pinMode(options_.resetButtonPin,
          options_.resetButtonActiveLow ? INPUT_PULLUP : INPUT_PULLDOWN);
  configurePortalRoutes();
  loadNetworkSettings();

  WiFi.persistent(false);
  WiFi.setAutoReconnect(true);
  if (wifiConfigSaved_ && wifiSsid_[0]) beginWifiAttempt(wifiSsid_, wifiPassword_, false);
  else startPortal();

  begun_ = true;
  logf("[Bridge] Device ID: %s", deviceId_);
  return true;
}

void WebBridge::end() {
  if (!begun_) return;
  stopMqtt();
  stopPortal();
  prefs_.end();
  begun_ = false;
}

void WebBridge::loop() {
  if (!begun_) return;
  serviceResetButton();
  serviceScheduledRestart();
  servicePortal();
  serviceNetwork();
  serviceMqtt();
  processOneRx();

  const bool active = sessionActive();
  if (active != sessionWasActive_) {
    sessionWasActive_ = active;
    setRealtimeWifi(active);
    presencePending_ = true;
    if (callbacks_.onSessionChanged) callbacks_.onSessionChanged(callbacks_.context, active);
  }
  if (presencePending_ && mqttConnected_) publishPresence(true);
}

bool WebBridge::sessionActive() const {
  return sessionUntil_ != 0U && !deadlineReached(sessionUntil_);
}

bool WebBridge::takeSyncRequest() {
  const bool requested = syncRequested_;
  syncRequested_ = false;
  return requested;
}

bool WebBridge::publish(OutboundChannel channel,
                        const char *payload,
                        size_t payloadLength,
                        int qos,
                        int retain,
                        bool store) {
  const char *topic = topicFor(channel);
  if (!topic || !payload || payloadLength == 0U) return false;
  if (qos < 0) {
    qos = (channel == OutboundChannel::Snapshot) ? 0 : 1;
  }
  if (retain < 0) {
    retain = (channel == OutboundChannel::ConfigReported) ? 1 : 0;
  }
  const bool queued = enqueuePublish(topic, payload, payloadLength,
                                     qos, retain != 0, store);
  if (channel != OutboundChannel::Snapshot) {
    logf("[MQTT TX] channel=%u bytes=%u qos=%d retain=%d queued=%u",
         static_cast<unsigned>(channel),
         static_cast<unsigned>(payloadLength), qos, retain, queued ? 1U : 0U);
  }
  return queued;
}

void WebBridge::clearNetworkAndOpenPortal() {
  clearNetworkSettings();
  stopMqtt();
  WiFi.disconnect(true, true);
  startPortal();
}

void WebBridge::log(const char *message) const {
  if (options_.enableSerialLog && message) Serial.println(message);
}

void WebBridge::logf(const char *format, ...) const {
  if (!options_.enableSerialLog || !format) return;
  char buffer[220];
  va_list args;
  va_start(args, format);
  vsnprintf(buffer, sizeof(buffer), format, args);
  va_end(args);
  Serial.println(buffer);
}

void WebBridge::makeIdentity() {
  const uint64_t mac = ESP.getEfuseMac() & 0xFFFFFFFFFFFFULL;
  snprintf(deviceId_, sizeof(deviceId_), "MAP-%012llX",
           static_cast<unsigned long long>(mac));
  snprintf(apSsid_, sizeof(apSsid_), "%s-%04X",
           options_.apPrefix ? options_.apPrefix : "MAYAP",
           static_cast<unsigned>(mac & 0xFFFFULL));
}

void WebBridge::buildTopics() {
  const char *root = options_.topicRoot ? options_.topicRoot : "mayap/v1";
  snprintf(topicBase_, sizeof(topicBase_), "%s/%s", root, deviceId_);
  snprintf(topicConfigSet_, sizeof(topicConfigSet_), "%s/config/set", topicBase_);
  snprintf(topicConfigReported_, sizeof(topicConfigReported_), "%s/config/reported", topicBase_);
  snprintf(topicCommand_, sizeof(topicCommand_), "%s/command", topicBase_);
  snprintf(topicAck_, sizeof(topicAck_), "%s/ack", topicBase_);
  snprintf(topicSnapshot_, sizeof(topicSnapshot_), "%s/snapshot", topicBase_);
  snprintf(topicLog_, sizeof(topicLog_), "%s/log", topicBase_);
  snprintf(topicPresence_, sizeof(topicPresence_), "%s/presence", topicBase_);
  snprintf(topicSession_, sizeof(topicSession_), "%s/session", topicBase_);
  snprintf(lastWill_, sizeof(lastWill_),
           "{\"online\":false,\"deviceId\":\"%s\"}", deviceId_);
}

bool WebBridge::loadNetworkSettings() {
  memset(wifiSsid_, 0, sizeof(wifiSsid_));
  memset(wifiPassword_, 0, sizeof(wifiPassword_));
  if (!prefs_.begin("mayapnet", false)) return false;
  wifiConfigSaved_ = prefs_.getBool("configured", false);
  copyText(wifiSsid_, sizeof(wifiSsid_), prefs_.getString("ssid", ""));
  copyText(wifiPassword_, sizeof(wifiPassword_), prefs_.getString("wpass", ""));
  if (!wifiSsid_[0]) wifiConfigSaved_ = false;
  return true;
}

bool WebBridge::savePendingNetworkSettings() {
  const bool okSsid = prefs_.putString("ssid", pendingSsid_) == strlen(pendingSsid_);
  const bool okPass = prefs_.putString("wpass", pendingWifiPassword_) == strlen(pendingWifiPassword_);
  const bool okFlag = prefs_.putBool("configured", true) == 1;
  const bool verify = prefs_.getString("ssid", "") == pendingSsid_ &&
                      prefs_.getString("wpass", "") == pendingWifiPassword_ &&
                      prefs_.getBool("configured", false);
  if (!okSsid || !okPass || !okFlag || !verify) return false;
  copyText(wifiSsid_, sizeof(wifiSsid_), pendingSsid_);
  copyText(wifiPassword_, sizeof(wifiPassword_), pendingWifiPassword_);
  wifiConfigSaved_ = true;
  return true;
}

void WebBridge::clearNetworkSettings() {
  prefs_.clear();
  wifiConfigSaved_ = false;
  wifiSsid_[0] = '\0';
  wifiPassword_[0] = '\0';
}

void WebBridge::beginWifiAttempt(const char *ssid,
                                 const char *password,
                                 bool saveAfterConnect) {
  if (!ssid || !ssid[0]) return;
  pendingSaveAfterConnect_ = saveAfterConnect;
  wifiAttemptActive_ = true;
  wifiAttemptStartedAt_ = millis();
  state_ = ConnectionState::WifiConnecting;
  WiFi.mode(portalActive_ ? WIFI_AP_STA : WIFI_STA);
  WiFi.disconnect(false, false);
  WiFi.begin(ssid, password && password[0] ? password : nullptr);
  logf("[WiFi] Dang ket noi: %s", ssid);
}

void WebBridge::serviceNetwork() {
  const bool connected = WiFi.status() == WL_CONNECTED;
  if (connected && !wifiWasConnected_) {
    wifiWasConnected_ = true;
    wifiAttemptActive_ = false;
    if (pendingSaveAfterConnect_) {
      if (!savePendingNetworkSettings()) {
        log("[WiFi] Loi luu NVS");
        pendingSaveAfterConnect_ = false;
        return;
      }
      pendingSaveAfterConnect_ = false;
    }
    onWifiConnected();
  } else if (!connected && wifiWasConnected_) {
    wifiWasConnected_ = false;
    onWifiDisconnected();
  }

  if (wifiAttemptActive_ && millis() - wifiAttemptStartedAt_ >= options_.wifiConnectTimeoutMs) {
    wifiAttemptActive_ = false;
    pendingSaveAfterConnect_ = false;
    log("[WiFi] Het thoi gian ket noi");
    if (!portalActive_) startPortal();
  }

  if (!connected && !wifiAttemptActive_ && wifiConfigSaved_ && !portalActive_ &&
      deadlineReached(wifiReconnectAt_)) {
    wifiReconnectAt_ = millis() + options_.wifiReconnectMs;
    beginWifiAttempt(wifiSsid_, wifiPassword_, false);
  }
}

void WebBridge::onWifiConnected() {
  logf("[WiFi] Da ket noi, IP: %s", WiFi.localIP().toString().c_str());
  if (portalActive_) stopPortal();
  if (validBrokerUri(brokerUri_)) {
    state_ = isSecureBroker() ? ConnectionState::TimeSync
                              : ConnectionState::MqttConnecting;
    mqttStartAt_ = millis();
    presencePending_ = true;
  } else {
    state_ = ConnectionState::Offline;
    log("[MQTT] Broker chua duoc cau hinh; may van chay OFFLINE");
  }
}

void WebBridge::onWifiDisconnected() {
  state_ = ConnectionState::Offline;
  mqttConnected_ = false;
  sessionUntil_ = 0;
  setRealtimeWifi(false);
  if (callbacks_.onConnectionChanged) callbacks_.onConnectionChanged(callbacks_.context, false);
  log("[WiFi] Mat ket noi");
}

void WebBridge::configurePortalRoutes() {
  if (routesConfigured_) return;
  server_.on("/", HTTP_GET, [this]() { handlePortalIndex(); });
  server_.on("/api/status", HTTP_GET, [this]() { handlePortalStatus(); });
  server_.on("/api/networks", HTTP_GET, [this]() { handlePortalNetworks(); });
  server_.on("/api/save", HTTP_POST, [this]() { handlePortalSave(); });
  server_.on("/api/reset", HTTP_POST, [this]() { handlePortalReset(); });
  server_.on("/api/restart", HTTP_POST, [this]() { handlePortalRestart(); });
  server_.on("/generate_204", HTTP_GET, [this]() { handlePortalRedirect(); });
  server_.on("/gen_204", HTTP_GET, [this]() { handlePortalRedirect(); });
  server_.on("/hotspot-detect.html", HTTP_GET, [this]() { handlePortalRedirect(); });
  server_.on("/connecttest.txt", HTTP_GET, [this]() { handlePortalRedirect(); });
  server_.on("/ncsi.txt", HTTP_GET, [this]() { handlePortalRedirect(); });
  server_.on("/fwlink", HTTP_GET, [this]() { handlePortalRedirect(); });
  server_.onNotFound([this]() { handlePortalRedirect(); });
  routesConfigured_ = true;
}

void WebBridge::startPortal() {
  if (portalActive_) return;
  stopMqtt();
  WiFi.mode(WIFI_AP_STA);
  WiFi.softAPConfig(kPortalIp, kPortalIp, IPAddress(255, 255, 255, 0));
  if (!WiFi.softAP(apSsid_)) {
    log("[Portal] Khong tao duoc AP");
    return;
  }
  dns_.setErrorReplyCode(DNSReplyCode::NoError);
  dns_.start(kDnsPort, "*", kPortalIp);
  server_.begin();
  webServerStarted_ = true;
  portalActive_ = true;
  state_ = ConnectionState::Portal;
  beginScan();
  logf("[Portal] AP=%s IP=%s", apSsid_, kPortalIp.toString().c_str());
}

void WebBridge::stopPortal() {
  if (!portalActive_ && !webServerStarted_) return;
  dns_.stop();
  if (webServerStarted_) server_.stop();
  WiFi.softAPdisconnect(true);
  if (WiFi.status() == WL_CONNECTED) WiFi.mode(WIFI_STA);
  webServerStarted_ = false;
  portalActive_ = false;
}

void WebBridge::servicePortal() {
  if (!portalActive_) return;
  dns_.processNextRequest();
  server_.handleClient();
}

void WebBridge::beginScan() {
  WiFi.scanDelete();
  WiFi.scanNetworks(true, true);
}

void WebBridge::sendJson(int code, const char *json) {
  server_.sendHeader("Cache-Control", "no-store, no-cache, must-revalidate");
  server_.send(code, "application/json; charset=utf-8", json ? json : "{}");
}

void WebBridge::sendMessage(int code, const char *message) {
  char escaped[240];
  jsonEscapeTo(message ? message : "", escaped, sizeof(escaped));
  char body[280];
  snprintf(body, sizeof(body), "{\"message\":\"%s\"}", escaped);
  sendJson(code, body);
}

void WebBridge::handlePortalIndex() {
  server_.sendHeader("Cache-Control", "no-store");
  server_.send_P(200, "text/html; charset=utf-8", kPortalHtml);
}

void WebBridge::handlePortalStatus() {
  const char *message = "San sang";
  if (wifiAttemptActive_) message = "ESP32 dang kiem tra Wi-Fi";
  else if (WiFi.status() == WL_CONNECTED) message = "Wi-Fi da ket noi";
  else if (portalActive_) message = "Dang o che do cai dat";
  char body[420];
  snprintf(body, sizeof(body),
           "{\"deviceId\":\"%s\",\"connected\":%s,\"saved\":%s,"
           "\"mqtt\":%s,\"state\":%u,\"message\":\"%s\",\"ip\":\"%s\"}",
           deviceId_, wifiOnline() ? "true" : "false",
           wifiConfigSaved_ ? "true" : "false",
           mqttConnected_ ? "true" : "false",
           static_cast<unsigned>(state_), message,
           wifiOnline() ? WiFi.localIP().toString().c_str() : "");
  sendJson(200, body);
}

void WebBridge::handlePortalNetworks() {
  if (server_.hasArg("rescan") && server_.arg("rescan") == "1") {
    beginScan();
    sendJson(200, "{\"scanning\":true,\"networks\":[]}");
    return;
  }
  const int count = WiFi.scanComplete();
  if (count == WIFI_SCAN_RUNNING) {
    sendJson(200, "{\"scanning\":true,\"networks\":[]}");
    return;
  }
  if (count < 0) {
    beginScan();
    sendJson(200, "{\"scanning\":true,\"networks\":[]}");
    return;
  }

  String body;
  body.reserve(1600);
  body = F("{\"scanning\":false,\"networks\":[");
  String seen[kMaxScanResults];
  size_t unique = 0;
  for (int i = 0; i < count && unique < kMaxScanResults; ++i) {
    const String ssid = WiFi.SSID(i);
    if (!ssid.length()) continue;
    bool duplicate = false;
    for (size_t j = 0; j < unique; ++j) if (seen[j] == ssid) { duplicate = true; break; }
    if (duplicate) continue;
    seen[unique++] = ssid;
    String escaped = ssid;
    escaped.replace("\\", "\\\\");
    escaped.replace("\"", "\\\"");
    if (unique > 1) body += ',';
    body += F("{\"ssid\":\""); body += escaped;
    body += F("\",\"rssi\":"); body += String(WiFi.RSSI(i)); body += '}';
  }
  body += F("]}");
  sendJson(200, body.c_str());
}

void WebBridge::handlePortalSave() {
  copyText(pendingSsid_, sizeof(pendingSsid_), server_.arg("ssid"));
  copyText(pendingWifiPassword_, sizeof(pendingWifiPassword_), server_.arg("password"));
  if (!pendingSsid_[0]) {
    sendMessage(400, "Ten Wi-Fi khong duoc de trong.");
    return;
  }
  const size_t passLength = strlen(pendingWifiPassword_);
  if (passLength && passLength < 8) {
    sendMessage(400, "Mat khau Wi-Fi phai de trong hoac co it nhat 8 ky tu.");
    return;
  }
  beginWifiAttempt(pendingSsid_, pendingWifiPassword_, true);
  sendMessage(202, "Da nhan; ESP32 dang kiem tra Wi-Fi.");
}

void WebBridge::handlePortalReset() {
  clearNetworkSettings();
  wifiAttemptActive_ = false;
  pendingSaveAfterConnect_ = false;
  WiFi.disconnect(true, true);
  sendMessage(202, "Da xoa Wi-Fi. Che do cai dat van dang mo.");
}

void WebBridge::handlePortalRestart() {
  sendMessage(202, "ESP32 dang khoi dong lai.");
  restartPending_ = true;
  restartAt_ = millis() + 500U;
}

void WebBridge::handlePortalRedirect() {
  server_.sendHeader("Location", "http://192.168.4.1/", true);
  server_.send(302, "text/plain", "MAYAP");
}

bool WebBridge::startMqtt() {
  if (mqttStarted_ || !wifiOnline() || !validBrokerUri(brokerUri_)) return mqttStarted_;
  if (isSecureBroker() && !options_.allowInsecureTls && !options_.rootCaPem) {
    log("[MQTT] Thieu Root CA");
    mqttStartAt_ = millis() + options_.mqttReconnectMs;
    return false;
  }

  esp_mqtt_client_config_t config = {};
#if ESP_IDF_VERSION_MAJOR >= 5
  config.broker.address.uri = brokerUri_;
  if (isSecureBroker()) {
    config.broker.verification.certificate = options_.allowInsecureTls ? nullptr : options_.rootCaPem;
    config.broker.verification.skip_cert_common_name_check = options_.allowInsecureTls;
  }
  config.credentials.client_id = deviceId_;
  config.credentials.username = mqttUsername_[0] ? mqttUsername_ : nullptr;
  config.credentials.authentication.password = mqttPassword_[0] ? mqttPassword_ : nullptr;
  config.session.keepalive = options_.keepAliveSeconds;
  config.session.disable_clean_session = false;
  config.session.last_will.topic = topicPresence_;
  config.session.last_will.msg = lastWill_;
  config.session.last_will.msg_len = strlen(lastWill_);
  config.session.last_will.qos = 1;
  config.session.last_will.retain = 1;
  config.network.reconnect_timeout_ms = options_.mqttReconnectMs;
  config.network.timeout_ms = options_.networkTimeoutMs;
  config.task.stack_size = options_.mqttTaskStackBytes;
  config.task.priority = options_.mqttTaskPriority;
  config.buffer.size = RX_PAYLOAD_MAX;
  config.buffer.out_size = RX_PAYLOAD_MAX;
#else
  config.uri = brokerUri_;
  config.cert_pem = isSecureBroker() && !options_.allowInsecureTls ? options_.rootCaPem : nullptr;
  config.skip_cert_common_name_check = options_.allowInsecureTls;
  config.client_id = deviceId_;
  config.username = mqttUsername_[0] ? mqttUsername_ : nullptr;
  config.password = mqttPassword_[0] ? mqttPassword_ : nullptr;
  config.keepalive = options_.keepAliveSeconds;
  config.disable_clean_session = false;
  config.lwt_topic = topicPresence_;
  config.lwt_msg = lastWill_;
  config.lwt_msg_len = strlen(lastWill_);
  config.lwt_qos = 1;
  config.lwt_retain = 1;
  config.reconnect_timeout_ms = options_.mqttReconnectMs;
  config.network_timeout_ms = options_.networkTimeoutMs;
  config.task_stack = options_.mqttTaskStackBytes;
  config.task_prio = options_.mqttTaskPriority;
  config.buffer_size = RX_PAYLOAD_MAX;
  config.out_buffer_size = RX_PAYLOAD_MAX;
#endif

  mqttClient_ = esp_mqtt_client_init(&config);
  if (!mqttClient_) return false;
  esp_mqtt_client_register_event(mqttClient_,
      static_cast<esp_mqtt_event_id_t>(ESP_EVENT_ANY_ID), mqttEventThunk, this);
  if (esp_mqtt_client_start(mqttClient_) != ESP_OK) {
    esp_mqtt_client_destroy(mqttClient_);
    mqttClient_ = nullptr;
    mqttStartAt_ = millis() + options_.mqttReconnectMs;
    return false;
  }
  mqttStarted_ = true;
  state_ = ConnectionState::MqttConnecting;
  return true;
}

void WebBridge::stopMqtt() {
  if (!mqttClient_) {
    mqttStarted_ = false;
    mqttConnected_ = false;
    return;
  }
  esp_mqtt_client_stop(mqttClient_);
  esp_mqtt_client_destroy(mqttClient_);
  mqttClient_ = nullptr;
  mqttStarted_ = false;
  mqttConnected_ = false;
}

void WebBridge::serviceMqtt() {
  if (!wifiOnline() || portalActive_ || !validBrokerUri(brokerUri_)) return;
  if (isSecureBroker() && !options_.allowInsecureTls && !timeReadyForTls()) {
    state_ = ConnectionState::TimeSync;
    return;
  }
  if (!mqttStarted_) {
    if (!mqttStartAt_ || deadlineReached(mqttStartAt_)) {
      mqttStartAt_ = millis() + options_.mqttReconnectMs;
      startMqtt();
    }
    return;
  }

  if (mqttConnectionEvent_ != 0) {
    const int8_t event = mqttConnectionEvent_;
    mqttConnectionEvent_ = 0;
    if (callbacks_.onConnectionChanged) callbacks_.onConnectionChanged(callbacks_.context, event > 0);
  }
}

bool WebBridge::timeReadyForTls() {
  if (time(nullptr) > static_cast<time_t>(kMinValidEpoch)) return true;
  static bool requested = false;
  if (!requested) {
    configTime(0, 0, "time.cloudflare.com", "pool.ntp.org", "time.google.com");
    requested = true;
  }
  return false;
}

bool WebBridge::isSecureBroker() const {
  return startsWith(brokerUri_, "mqtts://") || startsWith(brokerUri_, "wss://");
}

void WebBridge::setRealtimeWifi(bool active) {
  if (!wifiOnline() || realtimeWifi_ == active) return;
  const wifi_ps_type_t mode = active ? WIFI_PS_NONE : WIFI_PS_MIN_MODEM;
  if (esp_wifi_set_ps(mode) == ESP_OK) realtimeWifi_ = active;
}

void WebBridge::processOneRx() {
  if (!rxQueue_) return;
  if (xQueueReceive(rxQueue_, &rxProcessing_, 0) != pdTRUE) return;
  if (rxProcessing_.kind == RxKind::Session) {
    handleSessionPayload(rxProcessing_.payload, rxProcessing_.length, rxProcessing_.retained);
    return;
  }
  if (!callbacks_.onMessage) return;
  const InboundChannel channel = rxProcessing_.kind == RxKind::Config
      ? InboundChannel::ConfigSet : InboundChannel::Command;
  callbacks_.onMessage(callbacks_.context, channel, rxProcessing_.payload,
                       rxProcessing_.length, rxProcessing_.retained);
}

void WebBridge::handleSessionPayload(const char *payload, size_t length, bool retained) {
  if (retained || !payload || !length) return;
  bool active = false;
  bool sync = false;
  uint32_t ttl = options_.sessionDefaultMs;
  if (!readJsonBool(payload, "active", active)) return;
  (void)readJsonBool(payload, "sync", sync);
  (void)readJsonU32(payload, "ttlMs", ttl);
  if (ttl < 1000U) ttl = 1000U;
  if (ttl > options_.sessionMaxMs) ttl = options_.sessionMaxMs;
  sessionUntil_ = active ? millis() + ttl : 0U;
  if (sync) syncRequested_ = true;
}

WebBridge::RxKind WebBridge::classifyTopic(const char *topic, size_t length) const {
  if (!topic || !length) return RxKind::Unknown;
  if (length == strlen(topicConfigSet_) && memcmp(topic, topicConfigSet_, length) == 0) return RxKind::Config;
  if (length == strlen(topicCommand_) && memcmp(topic, topicCommand_, length) == 0) return RxKind::Command;
  if (length == strlen(topicSession_) && memcmp(topic, topicSession_, length) == 0) return RxKind::Session;
  return RxKind::Unknown;
}

bool WebBridge::enqueuePublish(const char *topic, const char *payload, size_t length,
                               int qos, bool retain, bool store) {
  if (!mqttClient_ || !mqttConnected_ || !topic || !payload || !length) return false;
  if (options_.maxOutboxBytes &&
      esp_mqtt_client_get_outbox_size(mqttClient_) > static_cast<int>(options_.maxOutboxBytes)) {
    return false;
  }
  const int id = esp_mqtt_client_enqueue(mqttClient_, topic, payload,
                                         static_cast<int>(length), qos,
                                         retain ? 1 : 0, store);
  return id >= 0;
}

const char *WebBridge::topicFor(OutboundChannel channel) const {
  switch (channel) {
    case OutboundChannel::ConfigReported: return topicConfigReported_;
    case OutboundChannel::Ack: return topicAck_;
    case OutboundChannel::Snapshot: return topicSnapshot_;
    case OutboundChannel::Log: return topicLog_;
    default: return nullptr;
  }
}

void WebBridge::publishPresence(bool online) {
  char firmwareEsc[96];
  jsonEscapeTo(options_.firmwareVersion ? options_.firmwareVersion : "", firmwareEsc, sizeof(firmwareEsc));
  char payload[384];
  const int length = snprintf(payload, sizeof(payload),
      "{\"online\":%s,\"deviceId\":\"%s\",\"firmware\":\"%s\","
      "\"ip\":\"%s\",\"rssi\":%d,\"realtime\":%s}",
      online ? "true" : "false", deviceId_, firmwareEsc,
      wifiOnline() ? WiFi.localIP().toString().c_str() : "",
      wifiOnline() ? WiFi.RSSI() : 0,
      sessionActive() ? "true" : "false");
  if (length > 0 && static_cast<size_t>(length) < sizeof(payload) &&
      enqueuePublish(topicPresence_, payload, length, 1, true, true)) {
    presencePending_ = false;
  }
}

void WebBridge::mqttEventThunk(void *handlerArgs, esp_event_base_t,
                               int32_t eventId, void *eventData) {
  WebBridge *self = static_cast<WebBridge *>(handlerArgs);
  if (self) self->onMqttEvent(eventId, static_cast<esp_mqtt_event_handle_t>(eventData));
}

void WebBridge::onMqttEvent(int32_t eventId, esp_mqtt_event_handle_t event) {
  if (!event) return;
  switch (static_cast<esp_mqtt_event_id_t>(eventId)) {
    case MQTT_EVENT_CONNECTED:
      mqttConnected_ = true;
      state_ = ConnectionState::Online;
      esp_mqtt_client_subscribe(event->client, topicConfigSet_, 1);
      esp_mqtt_client_subscribe(event->client, topicCommand_, 1);
      esp_mqtt_client_subscribe(event->client, topicSession_, 0);
      presencePending_ = true;
      syncRequested_ = true;
      mqttConnectionEvent_ = 1;
      log("[MQTT] CONNECTED + SUBSCRIBED");
      break;

    case MQTT_EVENT_DISCONNECTED:
      mqttConnected_ = false;
      state_ = ConnectionState::MqttConnecting;
      sessionUntil_ = 0;
      mqttConnectionEvent_ = -1;
      log("[MQTT] DISCONNECTED");
      break;

    case MQTT_EVENT_DATA: {
      if (event->total_data_len <= 0 ||
          event->total_data_len > static_cast<int>(RX_PAYLOAD_MAX)) {
        ++rxOversize_;
        rxAssemblyExpected_ = 0;
        rxAssemblyOffset_ = 0;
        break;
      }
      if (event->current_data_offset == 0) {
        rxAssembly_ = RxPacket{};
        rxAssembly_.kind = classifyTopic(event->topic, event->topic_len);
        rxAssembly_.retained = event->retain;
        rxAssemblyExpected_ = static_cast<uint16_t>(event->total_data_len);
        rxAssemblyOffset_ = 0;
      }
      if (rxAssembly_.kind == RxKind::Unknown ||
          event->current_data_offset != static_cast<int>(rxAssemblyOffset_) ||
          static_cast<size_t>(rxAssemblyOffset_) + event->data_len > RX_PAYLOAD_MAX) {
        rxAssemblyExpected_ = 0;
        rxAssemblyOffset_ = 0;
        break;
      }
      memcpy(rxAssembly_.payload + rxAssemblyOffset_, event->data, event->data_len);
      rxAssemblyOffset_ = static_cast<uint16_t>(rxAssemblyOffset_ + event->data_len);
      if (rxAssemblyOffset_ == rxAssemblyExpected_) {
        rxAssembly_.length = rxAssemblyExpected_;
        rxAssembly_.payload[rxAssembly_.length] = '\0';
        if (!rxQueue_ || xQueueSend(rxQueue_, &rxAssembly_, 0) != pdTRUE) {
          ++rxDropped_;
          logf("[MQTT RX] DROP kind=%u bytes=%u queue=%u",
               static_cast<unsigned>(rxAssembly_.kind),
               static_cast<unsigned>(rxAssembly_.length),
               static_cast<unsigned>(rxQueue_ ? uxQueueMessagesWaiting(rxQueue_) : 0U));
        } else if (rxAssembly_.kind != RxKind::Session) {
          logf("[MQTT RX] kind=%s bytes=%u retained=%u",
               rxAssembly_.kind == RxKind::Config ? "CONFIG" : "COMMAND",
               static_cast<unsigned>(rxAssembly_.length),
               rxAssembly_.retained ? 1U : 0U);
        }
        rxAssemblyExpected_ = 0;
        rxAssemblyOffset_ = 0;
      }
      break;
    }

    case MQTT_EVENT_SUBSCRIBED:
      logf("[MQTT] SUBSCRIBED id=%d", event->msg_id);
      break;
    case MQTT_EVENT_PUBLISHED:
      logf("[MQTT] PUBLISHED id=%d", event->msg_id);
      break;
    case MQTT_EVENT_ERROR:
      log("[MQTT] ERROR");
      break;
    default:
      break;
  }
}

void WebBridge::serviceScheduledRestart() {
  if (!restartPending_ || !deadlineReached(restartAt_)) return;
  restartPending_ = false;
  ESP.restart();
}

void WebBridge::serviceResetButton() {
  const int level = digitalRead(options_.resetButtonPin);
  const bool pressed = options_.resetButtonActiveLow ? level == LOW : level == HIGH;
  if (pressed) {
    if (!resetPressedAt_) resetPressedAt_ = millis();
    if (!resetHandled_ && millis() - resetPressedAt_ >= options_.resetButtonHoldMs) {
      resetHandled_ = true;
      clearNetworkSettings();
      log("[BOOT] Da xoa Wi-Fi; tha nut de mo portal");
    }
    return;
  }
  if (resetHandled_) {
    resetHandled_ = false;
    resetPressedAt_ = 0;
    clearNetworkAndOpenPortal();
    return;
  }
  resetPressedAt_ = 0;
}

bool WebBridge::deadlineReached(uint32_t deadline) {
  return deadline != 0U && static_cast<int32_t>(millis() - deadline) >= 0;
}

bool WebBridge::copyText(char *destination, size_t capacity, const String &source) {
  return copyText(destination, capacity, source.c_str());
}

bool WebBridge::copyText(char *destination, size_t capacity, const char *source) {
  if (!destination || !capacity) return false;
  if (!source) source = "";
  const size_t length = strlen(source);
  if (length >= capacity) {
    destination[0] = '\0';
    return false;
  }
  memcpy(destination, source, length + 1U);
  return true;
}

bool WebBridge::validBrokerUri(const char *value) {
  return value && (startsWith(value, "mqtt://") || startsWith(value, "mqtts://") ||
                   startsWith(value, "ws://") || startsWith(value, "wss://"));
}

void WebBridge::jsonEscapeTo(const char *input, char *output, size_t capacity) {
  if (!output || !capacity) return;
  size_t used = 0;
  if (!input) input = "";
  while (*input && used + 1U < capacity) {
    const char c = *input++;
    const char *replacement = nullptr;
    switch (c) {
      case '\\': replacement = "\\\\"; break;
      case '"': replacement = "\\\""; break;
      case '\n': replacement = "\\n"; break;
      case '\r': replacement = "\\r"; break;
      case '\t': replacement = "\\t"; break;
      default: break;
    }
    if (replacement) {
      const size_t n = strlen(replacement);
      if (used + n >= capacity) break;
      memcpy(output + used, replacement, n);
      used += n;
    } else if (static_cast<uint8_t>(c) >= 0x20U) {
      output[used++] = c;
    }
  }
  output[used] = '\0';
}

}  // namespace mayap

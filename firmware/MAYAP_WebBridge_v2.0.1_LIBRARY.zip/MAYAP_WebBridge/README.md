# MAYAP WebBridge 2.0.0

Thư viện vận chuyển MQTT + captive portal Wi-Fi cho ESP32. Thư viện **không biết**
`MachineConfig`, PID, IO, HMI hay tên lệnh của máy. Toàn bộ schema và ánh xạ lệnh nằm
trong dự án điều khiển.

## Mục tiêu

- Máy vẫn điều khiển OFFLINE khi Wi-Fi/MQTT lỗi.
- MQTT callback chỉ ghép payload vào hàng đợi tĩnh rồi thoát.
- Không `delay()`, không `new/delete` theo từng bản tin trong thư viện.
- Publish bằng `esp_mqtt_client_enqueue()`.
- Thêm nút web mới không sửa thư viện.
- Captive portal ban đầu chỉ hỏi Wi-Fi và mật khẩu.

## Cấu trúc

```text
Website
   | MQTT JSON raw
MAYAP_WebBridge                 <- thư viện ổn định, không schema máy
   | InboundChannel/OutboundChannel
mayap_web_adapter.h             <- parser/serializer của dự án
   | mailbox cố định
MachineController               <- logic máy, EEPROM, PID, IO, an toàn
```

## API tối thiểu

```cpp
mayap::WebBridge bridge;

mayap::BridgeOptions options{};
options.brokerUri = "mqtts://broker.example.com:8883";
options.rootCaPem = ROOT_CA;

bridge.begin(options, adapter.callbacks());

void loop() {
  bridge.loop();
  adapter.loop();
}
```

## Topic

```text
mayap/v1/{deviceId}/config/set
mayap/v1/{deviceId}/config/reported
mayap/v1/{deviceId}/command
mayap/v1/{deviceId}/ack
mayap/v1/{deviceId}/snapshot
mayap/v1/{deviceId}/log
mayap/v1/{deviceId}/presence
mayap/v1/{deviceId}/session
```

## Thêm nút web mới

Không sửa `MAYAP_WebBridge.h/.cpp` và không sửa topic.

Trong dự án máy:

1. Thêm một giá trị vào `HmiCommandType`.
2. Thêm một `case` vào `MachineController::executeMachineCommand()`.
3. Thêm một dòng vào `MAYAP_WEB_COMMAND_TABLE()` trong `mayap_web_schema.h`.
4. Web gửi action tương ứng.

Các tham số chung `arg0`, `arg1`, `value` đã có sẵn cho lệnh mở rộng.

## Cài Arduino IDE

Cài file ZIP thư viện bằng:

```text
Sketch > Include Library > Add .ZIP Library
```

Sau đó mở ví dụ:

```text
File > Examples > MAYAP WebBridge > MAYAP_WebBridge_Standalone
```

## Lưu ý triển khai thương mại

- Không dùng broker công cộng cho máy thật.
- Dùng TLS và tài khoản/ACL giới hạn theo thiết bị.
- Broker credential không đưa vào captive portal người dùng.
- Bản tích hợp phải được compile bằng đúng Arduino-ESP32 và thử trên bo thật.

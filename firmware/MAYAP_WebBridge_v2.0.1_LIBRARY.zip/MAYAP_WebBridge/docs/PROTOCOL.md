# MAYAP Web Protocol v1

## Quy ước chung

- Trường `v` là phiên bản giao thức, hiện là `1`.
- `deviceId` được tạo từ MAC của ESP32.
- `bootId` đổi sau mỗi lần khởi động.
- Lệnh có rủi ro phải mang `bootId` hiện tại và `expiresAt`.
- `command` không retain; `config/set` có thể retain.

## Cấu hình xuống máy

Topic: `mayap/v1/{deviceId}/config/set`, QoS 1, retain.

```json
{
  "v": 1,
  "revision": 12,
  "requestId": "cfg-12",
  "config": {
    "targetTemp": 37.5
  }
}
```

Bản tích hợp v3.4.0 yêu cầu gửi đủ 28 trường. Máy chỉ phát trạng thái `applied`
sau khi EEPROM đã ghi, đọc lại và kiểm tra thành công.

## Lệnh xuống máy

Topic: `mayap/v1/{deviceId}/command`, QoS 1, không retain.

```json
{
  "v": 1,
  "sequence": 101,
  "requestId": "cmd-101",
  "bootId": 123456789,
  "action": "batch_start",
  "expiresAt": 1785312005,
  "arg0": 0,
  "arg1": 0,
  "value": 0
}
```

## ACK

Topic: `mayap/v1/{deviceId}/ack`, QoS 1.

Các trạng thái chính:

- `accepted`: core đã nhận yêu cầu, chưa đồng nghĩa chấp hành xong.
- `applied`: cấu hình đã lưu/đọc lại và được áp dụng.
- `rejected`: core từ chối theo logic an toàn.
- `invalid`: payload sai.
- `duplicate`: revision/sequence đã xử lý.

## Snapshot

Topic: `mayap/v1/{deviceId}/snapshot`, QoS 0.

- 2 giây khi web đang mở session.
- 30 giây khi không có session.
- Chẩn đoán nặng chỉ chèn khoảng 30 giây một lần.

## Log

Topic: `mayap/v1/{deviceId}/log`, QoS 1.

ESP32 gửi mã/số liệu ngắn; website chịu trách nhiệm đổi thành câu thân thiện.

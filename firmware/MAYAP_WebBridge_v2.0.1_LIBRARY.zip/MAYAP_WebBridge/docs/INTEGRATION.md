# Tích hợp vào MAYAP v3.3.0

Bản đã tích hợp sẵn nằm trong dự án `MAYAP_ONLINE_INDUSTRIAL_v3_4_0`.

## Những phần giữ nguyên

- Control task 5 ms.
- Supervisor task và watchdog.
- HMI/I2C task là chủ sở hữu duy nhất của Wire.
- EEPROM AT24C32 hai slot + CRC + đọc kiểm tra.
- PID, relay, cảm biến, đảo, cảnh báo và liên động an toàn.

## Những phần thêm

- `mayap_web_adapter.h`: ánh xạ JSON với core.
- `mayap_web_schema.h`: nguồn duy nhất của trường config và bảng lệnh.
- `mayap_web_credentials.h`: broker/TLS build-time.
- Mailbox/ring cố định trong `MachineController`.
- Snapshot bất biến do Control task công bố.
- Đọc tương thích EEPROM schema 3 và ghi schema 4.

## Luồng lưu cấu hình

```text
config/set
 -> adapter parse vào MachineConfig tạm
 -> mailbox WebConfigRequest
 -> Control task kiểm tra
 -> I2C queue
 -> HMI/I2C task ghi EEPROM A/B + CRC + readback
 -> I2cResult về Control task
 -> áp dụng cấu hình
 -> WebConfigResult
 -> ACK applied + config/reported
```

## Luồng lệnh

```text
command
 -> adapter kiểm tra v/bootId/expiresAt/sequence
 -> WebCommandRequest mailbox
 -> Control task
 -> executeMachineCommand() dùng chung với HMI
 -> WebCommandResult
 -> ACK
 -> snapshot xác nhận trạng thái thật
```

## Mở rộng nút mới

Ví dụ thêm nút bật/tắt đèn:

```cpp
// 1. config.h
enum class HmiCommandType : uint8_t {
  ...,
  LightToggle
};

// 2. machine_control.h, trong executeMachineCommand()
case HmiCommandType::LightToggle:
  // Gọi logic core hiện có; không digitalWrite trong adapter.
  accepted = requestLightToggle(command.value >= 0.5f);
  break;

// 3. mayap_web_schema.h
X("light_toggle", LightToggle, 5000U, 0U, false)
```

Website gửi:

```json
{
  "v":1,
  "sequence":202,
  "requestId":"cmd-202",
  "bootId":123456789,
  "action":"light_toggle",
  "value":1
}
```

Không sửa thư viện, không thêm topic và không viết parser mới.

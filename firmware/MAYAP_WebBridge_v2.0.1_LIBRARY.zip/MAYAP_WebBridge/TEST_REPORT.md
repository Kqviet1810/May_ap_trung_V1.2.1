# MAYAP WebBridge 2.0.0 - Test Report

Ngày kiểm tra: 2026-07-29

## Đã kiểm tra

- Cú pháp source thư viện với nhánh API ESP-IDF 5: PASS.
- Cú pháp source thư viện với nhánh API ESP-IDF 4: PASS.
- Cú pháp `machine_control.h` thực tế: PASS bằng host stubs.
- Cú pháp adapter dự án: PASS.
- Runtime adapter: PASS.
- Ví dụ Standalone: PASS bằng host stubs.
- JavaScript trang test MQTT: PASS bằng `node --check`.
- JavaScript captive portal: PASS bằng `node --check`.
- 28/28 trường cấu hình có trong schema: PASS.
- 9 lệnh có trong bảng lệnh: PASS.
- Thư viện không khai báo schema máy: PASS.
- Thư viện dùng queue tĩnh và `esp_mqtt_client_enqueue()`: PASS.
- Không có `delay()` trong source thư viện: PASS.

## Runtime adapter đã xác nhận

- Nhận cấu hình đủ 28 trường.
- Nhận `autoResumeAfterPower`.
- Ánh xạ action vào `HmiCommandType`.
- Nhận `arg0`, `arg1`, `value` dùng cho lệnh mở rộng.
- Sinh payload outgoing có protocol version.

## Chưa thể xác nhận trong môi trường này

- Compile/link bằng Arduino-ESP32 toolchain thật.
- Dung lượng flash/RAM cuối cùng sau link.
- TLS với broker thương mại thật.
- Reconnect Wi-Fi/MQTT dài ngày.
- Tương tác với bo ESP32-S3, EEPROM, RTC, LCD và tải thật.
- Soak test 7–30 ngày.

Bởi vậy đây là bản tích hợp kỹ thuật để nạp thử, chưa nên gọi là bản thương mại
đã nghiệm thu trước khi hoàn tất kiểm thử phần cứng và soak test.
